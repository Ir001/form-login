<?php
	session_start();
	require 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>
		<?php
			if (isset($_SESSION['user'])) {
				echo "Dashboard";
			}else{
				if (isset($_GET['register'])) {
					echo "Regsiter";
				}
				elseif (isset($_GET['forgot'])) {
					echo "Forgot Password";
				}elseif (isset($_GET['verification'])) {
					echo "Verification Password - ".$_SESSION['forgot_em'];
				}
				else{
					echo "Login";
				}
			}
		?>
		</title>
		<link href="css/style.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/mdb.min.css" rel="stylesheet">
	</head>
	<body>
		<div class="container-fluid">
			<?php
				if (isset($_SESSION['user'])) {
					if (isset($_GET['change'])) {
						require 'sys/change.php';
					}elseif(isset($_GET['edit'])){
						require 'sys/edit.php';
					}else{
						require 'sys/dashboard.php';
				}
				}else{
					if (isset($_GET['register'])) {
						require 'sys/register.php';
					}
					elseif (isset($_GET['forgot'])) {
						require 'sys/forgot.php';
					}elseif (isset($_GET['verification'])) {
						require 'sys/verification.php';
					}else{
						require 'sys/login.php';
					}
				}
			?>
		</div>
		<script type="text/javascript" src="js/popper.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/mdb.min.js"></script>
	</body>
</html>