<div class="container">
	<div class="row mt-5">
		<div class="col-md-12 card">
			<div class="row">
				<div class="col-md-4">
					<img src="img/Hago.jpg" class="img img-fluid" alt="Profile Picture">
				</div>
				<div class="col-md-8">
					<span style="float: right;">
						<a href="sys/logout.php" class="btn btn-danger">Logout</a>
					</span>
					<h3 class="mt-2">Welcome <?php echo $_SESSION['user']; ?></h3>
					<?php
						$sql = "SELECT * FROM user WHERE email = '".$_SESSION['email']."'";
						$query = mysqli_query($conn, $sql);
						$data = mysqli_fetch_assoc($query);
					?>
					<p>Name: <?php echo $data['username']; ?></p>
					<p>Email: <?php echo $data['email']; ?></p>
					<p>Password: <?php echo substr($data['password'], 0,10) ?>**** (Encrypted)</p>
					<a href="index.php?edit" class="btn btn-primary">Edit</a>
					<a href="index.php?change" class="btn btn-info">Change Password</a>
				</div>
			</div>
		</div>
	</div>
</div>