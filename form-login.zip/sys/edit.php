<div class="container">
	<div class="row mt-5">
		<div class="col-md-12 card">
			<div class="row">
				<div class="col-md-4">
					<img src="img/Hago.jpg" class="img img-fluid" alt="Profile Picture">
				</div>
				<div class="col-md-8">
					<span style="float: right;">
						<a href="sys/logout.php" class="btn btn-danger">Logout</a>
					</span>
					<h3 class="mt-2">Welcome <?php echo $_SESSION['user']; ?></h3>
					<?php
						$sql = "SELECT * FROM user WHERE email = '".$_SESSION['email']."'";
						$query = mysqli_query($conn, $sql);
						$data = mysqli_fetch_assoc($query);
						$msg = '';
						//
						if (isset($_POST['submit'])) {
							$username = mysqli_real_escape_string($conn, $_POST['username']);
							$email = $_SESSION['email'];
							$a = "UPDATE user SET username = '$username' WHERE email = '$email'";
							$b = mysqli_query($conn, $a);
							if ($a) {
								unset($_SESSION['user']);
								$_SESSION['user'] = $username; 
								$msg = '
								<p class="alert alert-success animated fadeOutLeft delay-2s">
												Sukses Mengubah Nama
								</p>
								';
							}else{
								$msg = '
								<p class="alert alert-danger animated fadeOutLeft delay-2s">
												Kesalahan Saat Mengubah Nama
								</p>
								';
							}
						}
					?>
					<form action="" method="POST">
						<div class="form-group">
							<?php echo $msg; ?>
						</div>
						<div class="form-group">
							<label for="username" class="control-label">Username:</label>
							<input type="text" name="username" class="form-control" value="<?php echo $data['username']; ?>" required>
						</div>
						<div class="form-group">
							<label for="email" class="control-label">Email:</label>
							<input type="email" class="form-control" value="<?php echo $data['email']; ?>" readonly>
						</div>
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-info">Update</button>
							<a href="index.php?dashboard">&larr; Back</a>
						</div>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>