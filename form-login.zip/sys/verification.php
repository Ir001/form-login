<?php
	$msg = '<p class="alert alert-success animated bounce">
								Periksa email anda perihal kode verifikasi
			</p>';
	if (!isset($_SESSION['forgot_em'])) {
		header("location:index.php?forgot");
	}else{
		if (isset($_POST['verif'])) {
			$msg = '
			<meta http-equiv="refresh" content=5; url="index.php?login" />
			<p class="alert alert-success animated fadeInLeft">
								Kami telah mengirimkan password anda. Harap check email dan login
			</p>
				';
		}

?>
<div class="container">
	<div class="row">
		<div class="col-md-7 mt-5">
			<?php echo $msg; ?>
		</div>
		<div class="card col-md-5 ml-auto mt-5 border border-primary shadow">
			<div class="card-body">
				<h2 class="text-center text-primary"><i class="fa fa-ok"></i> Verifikasi</h2>
				<form action="" method="POST">
					<div class="form-group">
						<p class="alert-alert-info">Kami telah mengirimkan kode verifikasi ke email <?php echo $_SESSION['forgot_em']; ?></p>
						<label for="kode" class="control-label"><i class="fa fa-unlock"></i> Kode Verifikasi:</label>
						<input type="text" name="kode" class="form-control" id="kode" placeholder="Kode Verifikasi">
					</div>
					<div class="form-group">
						<button type="submit" name="verif" class="btn btn-primary">Submit</button>
						<a href="index.php?forgot">&larr; Back</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php } ?>