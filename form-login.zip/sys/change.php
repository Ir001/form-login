<div class="container">
	<div class="row mt-5">
		<div class="col-md-12 card">
			<div class="row">
				<div class="col-md-4">
					<img src="img/Hago.jpg" class="img img-fluid" alt="Profile Picture">
				</div>
				<div class="col-md-8">
					<span style="float: right;">
						<a href="sys/logout.php" class="btn btn-danger">Logout</a>
					</span>
					<h3 class="mt-2">Welcome <?php echo $_SESSION['user']; ?></h3>
					<?php
						$sql = "SELECT * FROM user WHERE email = '".$_SESSION['email']."'";
						$query = mysqli_query($conn, $sql);
						$data = mysqli_fetch_assoc($query);
						$msg = '';
						//
						if (isset($_POST['submit'])) {
							$password = md5($_POST['currentpassword']);
							$newpassword = md5($_POST['newpassword']);
							$cnewpassword = md5($_POST['cnewpassword']);
							
							if ($newpassword != $cnewpassword) {
								$msg = '
								<p class="alert alert-danger animated fadeOutLeft delay-2s">
											Konfirmasi Password salah!
								</p>
							';
							}else{
								if ($password != $data['password']) {
										$msg = '
										<p class="alert alert-danger animated fadeOutLeft delay-2s">
																		Password salah!
										</p>
										';
								}else{
										$email = $_SESSION['email'];
										$a = "UPDATE user SET password = '$newpassword' WHERE email = '$email'";
										$b = mysqli_query($conn, $a);
										if ($b) {
												$msg = '
														<p class="alert alert-success animated fadeInLeft">
																				Sukses Mengubah Password
												</p>
												';
										}else{
												$msg = '
												<p class="alert alert-danger animated fadeOutLeft delay-2s">
																				Gagal Mengubah Password
												</p>
												';
										}
								}
							}
						}
					?>
					<form action="" method="POST">
						<?php echo $msg; ?>
						<div class="form-group">
							<label for="password" class="control-label">Current Password:</label>
							<input type="password" class="form-control" name="currentpassword" placeholder="Current Password">
						</div>
						<div class="form-group">
							<label for="password" class="control-label">New Password:</label>
							<input type="password" class="form-control" name="newpassword" placeholder="New Password">
						</div>
						<div class="form-group">
							<label for="password" class="control-label">Confirm New Password:</label>
							<input type="password" class="form-control" name="cnewpassword" placeholder="Confirm New Password">
						</div>
						<div class="form-gruop">
							<button type="submit" name="submit" class="btn btn-info">Update</button>
							<a href="index.php?dashboard">&larr; Back</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>