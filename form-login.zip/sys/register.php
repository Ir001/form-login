<?php
		$msg ='';
		if (@isset($_POST['register'])) {
			$username = mysqli_real_escape_string($conn, $_POST['username']);
			$email = mysqli_real_escape_string($conn, $_POST['email']);
			$password = mysqli_real_escape_string($conn, $_POST['password']);
			$repassword = mysqli_real_escape_string($conn, $_POST['repassword']);
			//
			$a = "SELECT * FROM user WHERE email = '".$email."'";
			$b = mysqli_query($conn, $a);
			$check = mysqli_num_rows($b);
			if ($check >= 1) {
				$msg = '
				<p class="alert alert-danger animated fadeOutLeft delay-2s">
											Email telah digunakan!
				</p>
				';
			}else{
				if ($password != $repassword) {
					$msg = '
				<p class="alert alert-danger animated fadeOutLeft delay-2s">
											Password tidak cocok!
				</p>
					';
				}else{
					$sql = "INSERT INTO user (username, email, password, level) VALUES ('$username','$email','".md5($password)."','user')";
					$query = mysqli_query($conn, $sql);
					//
					if ($query) {
						$_SESSION['user'] = $username;
						$_SESSION['email'] = $email;
						$msg = '
				<meta http-equiv="refresh" content=2; url="index.php?dashboard" />
				<p class="alert alert-success animated fadeOutLeft delay-2s">
											Akun berhasil dibuat, anda akan dialihkan ke halaman berikutnya.
				</p>
					';
					}else{
						$msg = '
				<p class="alert alert-danger animated fadeOutLeft delay-2s">
											Kesalahan system!
				</p>
						';
					}
				}
			}
		}
?>
<div class="container">
	<div class="row">
		<div class="col-md-7 mt-5 ">
			<?php echo $msg; ?>
		</div>
		<div class="col-md-5 mt-5 border border-primary shadow">
			<div class="card-body">
				<h2 class="text-center text-primary"><i class="fa fa-user-plus"></i> Register User</h2>
				<form action="" method="POST">
					<div class="form-group">
						<label for="email" class="control-label"><i class="fa fa-user"></i> Username:</label>
						<input type="text" name="username" class="form-control" id="username" placeholder="Email" required="">
					</div>
					<div class="form-group">
						<label for="email" class="control-label"><i class="fa fa-envelope"></i> Email:</label>
						<input type="email" name="email" class="form-control" id="email" placeholder="Email" required="">
					</div>
					<div class="form-group">
						<label for="password" class="control-label"><i class="fa fa-lock"></i> Password:</label>
						<input type="password" name="password" class="form-control" id="password" placeholder="Password" required="">
					</div>
					<div class="form-group">
						<label for="password" class="control-label"><i class="fa fa-lock"></i> Re-Password:</label>
						<input type="password" name="repassword" class="form-control" id="repassword" placeholder="Repeat Password" required="">
					</div>
					<div class="form-group">
						<p>Sudah punya akun? <a href="index.php">login</a></p>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary" name="register">Register</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>