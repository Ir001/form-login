<?php
	$msg = '';
		if (isset($_POST['forgot'])) {
			//
			$email = mysqli_real_escape_string($conn, $_POST['email']);
			//
			$sql = "SELECT * FROM user WHERE email = '$email'";
			$query = mysqli_query($conn, $sql);
			$row = mysqli_num_rows($query);
			$data = mysqli_fetch_assoc($query);
			if ($row == 1) {
				$_SESSION['forgot_em'] = $email;
			// 	$msg = '
			// <meta http-equiv="refresh" content=2; url="index.php?asdasdassd" />
			// <p class="alert alert-success animated fadeInLeft">
			// 					Kami telah mengirimkan email, segera lakukan verifikasi.
			// </p>
			// 	';
				header("location:index.php?verification");
				
			}else{
				$msg = '
			<p class="alert alert-danger animated fadeInLeft">
								Email tidak terdaftar. <a href="index.php?register.php">register</a>
			</p>
				';
			}
		}
?>
<div class="container">
	<div class="row">
		<div class="col-md-7 mt-5">
			<?php echo $msg; ?>
		</div>
		<div class="card col-md-5 ml-auto mt-5 border border-primary shadow">
			<div class="card-body">
				<h2 class="text-center text-primary"><i class="fa fa-lock"></i> Forgot Password</h2>
				<form action="" method="POST">
					<div class="form-group">
						<label for="email" class="control-label"><i class="fa fa-envelope"></i> Email:</label>
						<input type="email" name="email" class="form-control" id="email" placeholder="Email" required="">
					</div>
					<div class="form-group">
						<p>Belum punya akun? <a href="index.php?register">register</a></p>
					</div>
					<div class="form-group">
						<button type="submit" name="forgot" class="btn btn-primary">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>