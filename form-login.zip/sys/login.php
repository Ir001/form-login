<?php
	unset($_SESSION['forgot_em']);
	$msg = '';
		if (@isset($_POST['login'])) {
			//
			$email = mysqli_real_escape_string($conn, $_POST['email']);
			$password = mysqli_real_escape_string($conn, md5($_POST['password']));
			//
			$sql = "SELECT * FROM user WHERE email = '$email'";
			$query = mysqli_query($conn, $sql);
			$row = mysqli_num_rows($query);
			$data = mysqli_fetch_assoc($query);
			if ($row && $password == $data['password']) {
				$_SESSION['user'] = $data['username'];
				$_SESSION['email'] = $data['email'];
				$msg = '
			<meta http-equiv="refresh" content=2; url="index.php?dashboard" />
			<p class="alert alert-success animated fadeOutLeft delay-1s">
							Berhasil login, anda akan dialihkan <i class="fas fa-truck-loading"></i>
			</p>
				';
			}elseif ($row && $password != $data['password']) {
				$msg = '
			<p class="alert alert-danger animated fadeOutLeft delay-2s">
							Password salah!
			</p>
				';
			}
		}
?>
<div class="container">
	<div class="row">
		<div class="col-md-7 mt-5">
			<?php echo $msg; ?>
		</div>
		<div class="card col-md-5 ml-auto mt-5 border border-primary shadow">
			<div class="card-body">
				<h2 class="text-center text-primary"><i class="fa fa-user"></i> Login User</h2>
				<form action="" method="POST">
					<div class="form-group">
						<label for="email" class="control-label"><i class="fa fa-envelope"></i> Email:</label>
						<input type="email" name="email" class="form-control" id="email" placeholder="Email" required="">
					</div>
					<div class="form-group">
						<label for="password" class="control-label"><i class="fa fa-lock"></i> Password:</label>
						<input type="password" name="password" class="form-control" id="password" placeholder="Password" required="">
					</div>
					<div class="form-group">
						<p>Belum punya akun? <a href="index.php?register">register</a></p>
					</div>
					<div class="form-group">
						<button type="submit" name="login" class="btn btn-primary">Login</button>
						<a href="index.php?forgot" class="control-label">Forgot Password?</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>